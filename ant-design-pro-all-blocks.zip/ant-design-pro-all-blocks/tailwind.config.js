module.exports = {
  content: ['./src/**/*.tsx'],
};
